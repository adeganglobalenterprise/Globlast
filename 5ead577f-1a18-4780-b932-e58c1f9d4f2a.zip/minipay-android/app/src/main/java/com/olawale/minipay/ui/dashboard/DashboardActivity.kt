package com.olawale.minipay.ui.dashboard

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.olawale.minipay.MiniPayApplication
import com.olawale.minipay.R
import com.olawale.minipay.data.api.MiniPayApiService
import com.olawale.minipay.data.models.Transaction
import com.olawale.minipay.data.models.User
import com.olawale.minipay.ui.history.HistoryActivity
import com.olawale.minipay.ui.transaction.ReceiveMoneyActivity
import com.olawale.minipay.ui.transaction.SendMoneyActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Dashboard Activity for MiniPay
 * Developed by Olawale Abdul-Ganiyu
 * Displays user balance and quick actions
 */
class DashboardActivity : AppCompatActivity() {
    
    private lateinit var apiService: MiniPayApiService
    private lateinit var currentUser: User
    
    private lateinit var balanceTextView: TextView
    private lateinit var accountNumberTextView: TextView
    private lateinit var userNameTextView: TextView
    private lateinit var recentTransactionsRecyclerView: RecyclerView
    private lateinit var transactionsAdapter: TransactionsAdapter
    
    private val recentTransactions = mutableListOf<Transaction>()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)
        
        apiService = MiniPayApiService.create()
        
        // Get current user from SharedPreferences or Intent
        loadCurrentUser()
        
        setupViews()
        setupClickListeners()
        loadDashboardData()
    }
    
    private fun setupViews() {
        supportActionBar?.title = "MiniPay Dashboard"
        supportActionBar?.subtitle = MiniPayApplication.OWNER_NAME
        
        balanceTextView = findViewById(R.id.balanceTextView)
        accountNumberTextView = findViewById(R.id.accountNumberTextView)
        userNameTextView = findViewById(R.id.userNameTextView)
        recentTransactionsRecyclerView = findViewById(R.id.recentTransactionsRecyclerView)
        
        // Setup RecyclerView
        transactionsAdapter = TransactionsAdapter(recentTransactions)
        recentTransactionsRecyclerView.apply {
            layoutManager = LinearLayoutManager(this@DashboardActivity)
            adapter = transactionsAdapter
        }
    }
    
    private fun setupClickListeners() {
        // Send Money Button
        findViewById<MaterialButton>(R.id.sendMoneyButton).setOnClickListener {
            startActivity(Intent(this, SendMoneyActivity::class.java))
        }
        
        // Receive Money Button
        findViewById<MaterialButton>(R.id.receiveMoneyButton).setOnClickListener {
            startActivity(Intent(this, ReceiveMoneyActivity::class.java))
        }
        
        // Add Credit Button
        findViewById<MaterialButton>(R.id.addCreditButton).setOnClickListener {
            showAddCreditDialog()
        }
        
        // Add Debit Button
        findViewById<MaterialButton>(R.id.addDebitButton).setOnClickListener {
            showAddDebitDialog()
        }
        
        // Edit Balance Button
        findViewById<MaterialButton>(R.id.editBalanceButton).setOnClickListener {
            showEditBalanceDialog()
        }
        
        // History Button
        findViewById<MaterialButton>(R.id.historyButton).setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
    }
    
    private fun loadCurrentUser() {
        // Load user from SharedPreferences or database
        // For demo purposes, we'll use a mock user
        currentUser = User(
            id = "user_001",
            fullName = "Olawale Abdul-Ganiyu",
            email = MiniPayApplication.GOOGLE_ACCOUNT,
            phone = "+1234567890",
            accountNumber = generateAccountNumber(),
            balance = 0.0,
            createdAt = System.currentTimeMillis().toString()
        )
    }
    
    private fun loadDashboardData() {
        CoroutineScope(Dispatchers.Main).launch {
            try {
                // Update UI with current user data
                updateDashboardUI()
                
                // Load recent transactions
                loadRecentTransactions()
                
            } catch (e: Exception) {
                Toast.makeText(
                    this@DashboardActivity,
                    "Error loading dashboard: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }
    
    private fun updateDashboardUI() {
        userNameTextView.text = "Welcome, ${currentUser.fullName}"
        balanceTextView.text = currentUser.getFormattedBalance()
        accountNumberTextView.text = "Account: ${currentUser.getMaskedAccountNumber()}"
    }
    
    private fun loadRecentTransactions() {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // In a real app, this would call the API
                // For demo, we'll use mock data
                val transactions = getMockTransactions()
                
                withContext(Dispatchers.Main) {
                    recentTransactions.clear()
                    recentTransactions.addAll(transactions.take(10))
                    transactionsAdapter.notifyDataSetChanged()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        this@DashboardActivity,
                        "Error loading transactions: ${e.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }
    
    private fun showAddCreditDialog() {
        // Show dialog to add credit
        val amount = 100.0
        val description = "Manual credit addition"
        
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Add credit transaction
                val transaction = Transaction(
                    id = generateTransactionId(),
                    userId = currentUser.id,
                    type = Transaction.TransactionType.CREDIT,
                    amount = amount,
                    description = description,
                    status = Transaction.TransactionStatus.COMPLETED,
                    createdAt = System.currentTimeMillis().toString(),
                    completedAt = System.currentTimeMillis().toString()
                )
                
                // Update user balance
                currentUser.balance += amount
                
                withContext(Dispatchers.Main) {
                    updateDashboardUI()
                    recentTransactions.add(0, transaction)
                    transactionsAdapter.notifyDataSetChanged()
                    
                    Toast.makeText(
                        this@DashboardActivity,
                        "Credit added: $${String.format("%.2f", amount)}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        this@DashboardActivity,
                        "Error adding credit: ${e.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }
    
    private fun showAddDebitDialog() {
        // Show dialog to add debit
        val amount = 50.0
        val description = "Manual debit deduction"
        
        if (amount > currentUser.balance) {
            Toast.makeText(
                this,
                "Insufficient balance",
                Toast.LENGTH_SHORT
            ).show()
            return
        }
        
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Add debit transaction
                val transaction = Transaction(
                    id = generateTransactionId(),
                    userId = currentUser.id,
                    type = Transaction.TransactionType.DEBIT,
                    amount = amount,
                    description = description,
                    status = Transaction.TransactionStatus.COMPLETED,
                    createdAt = System.currentTimeMillis().toString(),
                    completedAt = System.currentTimeMillis().toString()
                )
                
                // Update user balance
                currentUser.balance -= amount
                
                withContext(Dispatchers.Main) {
                    updateDashboardUI()
                    recentTransactions.add(0, transaction)
                    transactionsAdapter.notifyDataSetChanged()
                    
                    Toast.makeText(
                        this@DashboardActivity,
                        "Debit added: $${String.format("%.2f", amount)}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        this@DashboardActivity,
                        "Error adding debit: ${e.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }
    
    private fun showEditBalanceDialog() {
        // Show dialog to edit balance directly
        val newBalance = 500.0
        val reason = "Balance adjustment"
        
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val difference = newBalance - currentUser.balance
                
                if (difference != 0.0) {
                    val transaction = Transaction(
                        id = generateTransactionId(),
                        userId = currentUser.id,
                        type = if (difference > 0) Transaction.TransactionType.CREDIT else Transaction.TransactionType.DEBIT,
                        amount = Math.abs(difference),
                        description = reason,
                        status = Transaction.TransactionStatus.COMPLETED,
                        createdAt = System.currentTimeMillis().toString(),
                        completedAt = System.currentTimeMillis().toString()
                    )
                    
                    recentTransactions.add(0, transaction)
                }
                
                currentUser.balance = newBalance
                
                withContext(Dispatchers.Main) {
                    updateDashboardUI()
                    transactionsAdapter.notifyDataSetChanged()
                    
                    Toast.makeText(
                        this@DashboardActivity,
                        "Balance updated to $${String.format("%.2f", newBalance)}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(
                        this@DashboardActivity,
                        "Error updating balance: ${e.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }
    
    private fun getMockTransactions(): List<Transaction> {
        return listOf(
            Transaction(
                id = "tx_001",
                userId = currentUser.id,
                type = Transaction.TransactionType.CREDIT,
                amount = 100.0,
                description = "Initial deposit",
                status = Transaction.TransactionStatus.COMPLETED,
                createdAt = System.currentTimeMillis().toString()
            ),
            Transaction(
                id = "tx_002",
                userId = currentUser.id,
                type = Transaction.TransactionType.TRANSFER_SEND,
                amount = 50.0,
                description = "Transfer to friend",
                recipientName = "John Doe",
                recipientAccount = "MP1234567890",
                status = Transaction.TransactionStatus.COMPLETED,
                createdAt = (System.currentTimeMillis() - 3600000).toString()
            )
        )
    }
    
    private fun generateAccountNumber(): String {
        return "MP" + (1000000000 + Math.random() * 9000000000).toLong().toString()
    }
    
    private fun generateTransactionId(): String {
        return "tx_" + System.currentTimeMillis().toString()
    }
    
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.dashboard_menu, menu)
        return true
    }
    
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_settings -> {
                // Open settings
                true
            }
            R.id.action_logout -> {
                // Logout
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}