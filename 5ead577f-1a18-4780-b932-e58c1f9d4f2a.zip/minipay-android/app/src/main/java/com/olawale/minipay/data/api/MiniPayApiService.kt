package com.olawale.minipay.data.api

import com.olawale.minipay.MiniPayApplication
import com.olawale.minipay.data.models.Transaction
import com.olawale.minipay.data.models.User
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*
import java.util.concurrent.TimeUnit

/**
 * MiniPay API Service
 * Developed by Olawale Abdul-Ganiyu
 * API Base URL: https://api.olawale-minipay.com/v2/
 */
interface MiniPayApiService {
    
    // Authentication Endpoints
    @POST("auth/register")
    suspend fun register(
        @Body request: RegisterRequest
    ): ApiResponse<User>
    
    @POST("auth/login")
    suspend fun login(
        @Body request: LoginRequest
    ): ApiResponse<LoginResponse>
    
    @POST("auth/google")
    suspend fun googleLogin(
        @Body request: GoogleLoginRequest
    ): ApiResponse<LoginResponse>
    
    @POST("auth/logout")
    suspend fun logout(
        @Header("Authorization") token: String
    ): ApiResponse<Unit>
    
    @POST("auth/refresh")
    suspend fun refreshToken(
        @Body request: RefreshTokenRequest
    ): ApiResponse<LoginResponse>
    
    // User Endpoints
    @GET("users/me")
    suspend fun getCurrentUser(
        @Header("Authorization") token: String
    ): ApiResponse<User>
    
    @PUT("users/me")
    suspend fun updateCurrentUser(
        @Header("Authorization") token: String,
        @Body request: UpdateUserRequest
    ): ApiResponse<User>
    
    @GET("users/{userId}")
    suspend fun getUserById(
        @Header("Authorization") token: String,
        @Path("userId") userId: String
    ): ApiResponse<User>
    
    @GET("users/account/{accountNumber}")
    suspend fun getUserByAccountNumber(
        @Header("Authorization") token: String,
        @Path("accountNumber") accountNumber: String
    ): ApiResponse<User>
    
    // Balance Endpoints
    @GET("balance/me")
    suspend fun getBalance(
        @Header("Authorization") token: String
    ): ApiResponse<BalanceResponse>
    
    @POST("balance/credit")
    suspend fun addCredit(
        @Header("Authorization") token: String,
        @Body request: BalanceRequest
    ): ApiResponse<BalanceResponse>
    
    @POST("balance/debit")
    suspend fun addDebit(
        @Header("Authorization") token: String,
        @Body request: BalanceRequest
    ): ApiResponse<BalanceResponse>
    
    @PUT("balance/update")
    suspend fun updateBalance(
        @Header("Authorization") token: String,
        @Body request: UpdateBalanceRequest
    ): ApiResponse<BalanceResponse>
    
    // Transaction Endpoints
    @GET("transactions")
    suspend fun getTransactions(
        @Header("Authorization") token: String,
        @Query("page") page: Int = 1,
        @Query("limit") limit: Int = 20
    ): ApiResponse<TransactionListResponse>
    
    @GET("transactions/{transactionId}")
    suspend fun getTransactionById(
        @Header("Authorization") token: String,
        @Path("transactionId") transactionId: String
    ): ApiResponse<Transaction>
    
    @POST("transactions/transfer")
    suspend fun sendMoney(
        @Header("Authorization") token: String,
        @Body request: TransferRequest
    ): ApiResponse<Transaction>
    
    @POST("transactions/deposit")
    suspend fun depositMoney(
        @Header("Authorization") token: String,
        @Body request: DepositRequest
    ): ApiResponse<Transaction>
    
    @POST("transactions/withdraw")
    suspend fun withdrawMoney(
        @Header("Authorization") token: String,
        @Body request: WithdrawRequest
    ): ApiResponse<Transaction>
    
    // Admin Endpoints
    @GET("admin/users")
    suspend fun getAllUsers(
        @Header("Authorization") token: String,
        @Query("page") page: Int = 1,
        @Query("limit") limit: Int = 50
    ): ApiResponse<UserListResponse>
    
    @PUT("admin/users/{userId}/balance")
    suspend fun updateUserBalanceAdmin(
        @Header("Authorization") token: String,
        @Path("userId") userId: String,
        @Body request: UpdateBalanceRequest
    ): ApiResponse<User>
    
    @GET("admin/transactions")
    suspend fun getAllTransactions(
        @Header("Authorization") token: String,
        @Query("page") page: Int = 1,
        @Query("limit") limit: Int = 50
    ): ApiResponse<TransactionListResponse>
    
    @GET("admin/stats")
    suspend fun getAdminStats(
        @Header("Authorization") token: String
    ): ApiResponse<AdminStatsResponse>
    
    companion object {
        private const val BASE_URL = "https://api.olawale-minipay.com/v2/"
        
        fun create(): MiniPayApiService {
            val loggingInterceptor = HttpLoggingInterceptor().apply {
                level = HttpLoggingInterceptor.Level.BODY
            }
            
            val okHttpClient = OkHttpClient.Builder()
                .addInterceptor(loggingInterceptor)
                .connectTimeout(MiniPayApplication.API_TIMEOUT, TimeUnit.MILLISECONDS)
                .readTimeout(MiniPayApplication.API_TIMEOUT, TimeUnit.MILLISECONDS)
                .writeTimeout(MiniPayApplication.API_TIMEOUT, TimeUnit.MILLISECONDS)
                .addInterceptor { chain ->
                    val original = chain.request()
                    val requestBuilder = original.newBuilder()
                        .header("Accept", "application/json")
                        .header("Content-Type", "application/json")
                        .header("X-App-Version", MiniPayApplication.APP_VERSION)
                        .header("X-Platform", "Android")
                        .header("X-Owner", MiniPayApplication.OWNER_NAME)
                    chain.proceed(requestBuilder.build())
                }
                .build()
            
            val retrofit = Retrofit.Builder()
                .baseUrl(BASE_URL)
                .client(okHttpClient)
                .addConverterFactory(GsonConverterFactory.create(MiniPayApplication.gson))
                .build()
            
            return retrofit.create(MiniPayApiService::class.java)
        }
    }
}

// Request/Response Models
data class ApiResponse<T>(
    val success: Boolean,
    val data: T? = null,
    val message: String? = null,
    val error: String? = null
)

data class RegisterRequest(
    val fullName: String,
    val email: String,
    val phone: String,
    val password: String
)

data class LoginRequest(
    val email: String,
    val password: String
)

data class GoogleLoginRequest(
    val idToken: String,
    val googleAccount: String
)

data class RefreshTokenRequest(
    val refreshToken: String
)

data class LoginResponse(
    val user: User,
    val token: String,
    val refreshToken: String
)

data class UpdateUserRequest(
    val fullName: String? = null,
    val phone: String? = null,
    val googleAccount: String? = null
)

data class BalanceResponse(
    val balance: Double,
    val currency: String
)

data class BalanceRequest(
    val amount: Double,
    val description: String
)

data class UpdateBalanceRequest(
    val newBalance: Double,
    val reason: String
)

data class TransferRequest(
    val recipientAccount: String,
    val amount: Double,
    val description: String? = null
)

data class DepositRequest(
    val amount: Double,
    val method: String,
    val description: String? = null
)

data class WithdrawRequest(
    val amount: Double,
    val method: String,
    val accountDetails: String
)

data class TransactionListResponse(
    val transactions: List<Transaction>,
    val total: Int,
    val page: Int,
    val totalPages: Int
)

data class UserListResponse(
    val users: List<User>,
    val total: Int,
    val page: Int,
    val totalPages: Int
)

data class AdminStatsResponse(
    val totalUsers: Int,
    val totalTransactions: Int,
    val totalVolume: Double,
    val activeUsers: Int,
    val todayTransactions: Int,
    val todayVolume: Double
)